# Flow

Gestore di attività, **completamente locale**. Nessun account, nessuna
connessione a internet, nessuna dipendenza da installare. Tutto quello che scrivi
finisce in un unico file JSON sul tuo disco.

---

## Avvio

La **prima volta**: doppio clic su **`Flow.vbs`**. Oltre ad aprire l'app, crea
`Flow.lnk`, il collegamento con l'icona.

**Da lì in poi**: doppio clic su **`Flow.lnk`**. Puoi trascinarlo sulla barra
delle applicazioni o nel menu Start per averlo sempre a portata di mano.

Si apre una finestra dedicata, senza barra degli indirizzi né schede: sembra e si
comporta come un'applicazione.

Dietro le quinte il collegamento:

1. accende un piccolo server locale (`server.js`) su `127.0.0.1`, se non è già attivo;
2. apre Microsoft Edge (o Chrome) in modalità applicazione su quell'indirizzo.

Quando chiudi la finestra il server si accorge che nessuno lo sta più usando e si
spegne da solo dopo circa un minuto. Non resta niente in esecuzione.

### Serve internet?

No, mai. Il server ascolta **solo** su `127.0.0.1`, quindi non è raggiungibile
nemmeno dagli altri computer della tua rete. Font, icone e stili sono tutti dentro
la cartella: nessuna risorsa viene scaricata.

### E se Node.js non c'è?

Due strade:

- **copia `node.exe` dentro questa cartella** (lo fa `rendi-portabile.cmd`): Flow
  usa quello e non gli serve nient'altro installato sul computer;
- oppure apri `app\index.html` con un doppio clic. L'applicazione funziona lo
  stesso, ma in questa modalità i dati restano nell'archivio del browser invece
  che su file: usa **Esporta** dalle impostazioni per portarli via.

---

## Portabilità

Sì: puoi zippare la cartella e usarla altrove. Tutto quello che c'è dentro usa
percorsi **relativi** — `Flow.vbs` si orienta da sé, `start.cmd` usa `%~dp0`,
`server.js` usa `__dirname`. Funziona anche da chiavetta USB, con qualsiasi
lettera di unità, e anche se il percorso contiene spazi.

Due cose da sapere:

**1. Il collegamento si ripara da solo.** Un file `.lnk` di Windows contiene
percorsi assoluti, quindi dopo uno spostamento punterebbe alla vecchia posizione.
Al primo avvio in una nuova cartella, `Flow.vbs` se ne accorge e riscrive
`Flow.lnk`. Se hai spostato la cartella e il collegamento non risponde, avvia una
volta **`Flow.vbs`**: da lì in poi `Flow.lnk` torna a funzionare.

**2. Serve Node.js sul computer di destinazione**, a meno che tu non lo includa
nel pacchetto. Esegui una volta **`rendi-portabile.cmd`**: copia `node.exe`
accanto all'applicazione (circa 90 MB) e da quel momento la cartella è
autosufficiente. Flow preferisce sempre il `node.exe` locale, se lo trova.

Riassunto:

| Scenario | Serve installare qualcosa? |
|---|---|
| Cartella zippata, PC con Node.js | no |
| Cartella zippata + `rendi-portabile.cmd` eseguito | no, su nessun PC Windows |
| Cartella zippata, PC senza Node.js | solo `app\index.html`, dati nel browser |

I tuoi dati viaggiano con la cartella: sono in `data\board.json`, dentro il
pacchetto. Se preferisci un archivio pulito, cancella `data\` prima di zippare
(verrà ricreato al primo avvio) — ma **esporta prima**, se ti servono.

---

## Dove finiscono i dati

```
data\board.json          l'archivio: progetti, attività, etichette, impostazioni
data\backups\            copie automatiche, a rotazione: solo le ultime 25
```

Il salvataggio è automatico e avviene circa mezzo secondo dopo ogni modifica. La
scrittura è atomica (file temporaneo + rinomina), quindi un blocco improvviso del
computer non può lasciarti un archivio troncato. Una copia di sicurezza viene
messa da parte al massimo ogni 5 minuti.

Puoi copiare `data\board.json` dove vuoi: è il tuo archivio, in chiaro e leggibile.
Da **Impostazioni → Apri cartella** arrivi al file in due clic.

---

## Cosa sa fare

**Viste**

- **Oggi** — cruscotto con attività in ritardo, di oggi, dei prossimi 7 giorni,
  statistiche e andamento delle ultime settimane.
- **Bacheca** — colonne in stile kanban, con trascinamento tra le sezioni.
- **Elenco** — righe compatte raggruppate per sezione, riordinabili.
- **Calendario** — mese intero; trascina un'attività su un altro giorno per
  spostarne la scadenza.
- **Prossimi 7 giorni**, **Tutte le attività**, **Completate**.

**Attività**

Titolo, note in markdown leggero, scadenza, priorità, etichette colorate,
assegnatario, sotto-attività con barra di avanzamento, duplicazione.

**Etichette**

Il pulsante `…` accanto a *ETICHETTE*, in fondo alla barra laterale, apre la
gestione: crea, rinomina, cambia colore, elimina. Eliminandone una viene tolta
anche dalle attività che la usavano (annullabile con `Ctrl+Z`). Ci arrivi anche
col tasto destro su un'etichetta, o da `Ctrl+K` → *Gestisci etichette*.

Nel pannello di un'attività, il selettore delle etichette propone **Crea "…"**
mentre digiti un nome che non esiste ancora.

**Interfaccia**

Tema chiaro, scuro o automatico (segue Windows), colore principale
personalizzabile, densità comoda o compatta, barra laterale comprimibile.
Annulla e ripristina illimitati sulla sessione (`Ctrl+Z` / `Ctrl+Shift+Z`).

---

## Inserimento rapido

Premi `N` e scrivi in italiano naturale. Flow riconosce al volo:

| Cosa scrivi | Cosa diventa |
|---|---|
| `oggi`, `domani`, `dopodomani` | scadenza |
| `lunedì`, `ven`, `prossimo martedì` | scadenza |
| `tra 3 giorni`, `fra 2 settimane` | scadenza |
| `12/03`, `12-03-2026`, `12 marzo` | scadenza |
| `!alta` `!media` `!bassa` | priorità |
| `#casa` | etichetta (creata se non esiste) |
| `@Marco` | assegnatario (creato se non esiste) |
| `+Lavoro` | progetto di destinazione |

Esempio:

```
Chiamare il commercialista martedì !alta #urgente @Io +Lavoro
```

diventa un'attività intitolata *"Chiamare il commercialista"*, con scadenza a
martedì, priorità alta, etichetta `urgente`, assegnata a te, nel progetto *Lavoro*.

---

## Scorciatoie

| | |
|---|---|
| `Ctrl+K` | palette dei comandi (cerca tutto, esegui tutto) |
| `N` | nuova attività |
| `/` | vai alla ricerca |
| `Ctrl+Z` / `Ctrl+Shift+Z` | annulla / ripristina |
| `Ctrl+B` | mostra o nascondi la barra laterale |
| `Ctrl+Shift+P` | nuovo progetto |
| `Ctrl+E` | esporta l'archivio |
| `T` | cambia tema |
| `G` poi `O` `P` `A` `C` | vai a Oggi / Prossimi / Tutte / Completate |
| `1` `2` `3` | bacheca / elenco / calendario |
| `Esc` | chiudi pannello o finestra |
| `?` | elenco completo delle scorciatoie |

---

## Struttura della cartella

```
Flow.lnk            collegamento con icona (usa questo)
Flow.vbs            avvio: server + finestra applicazione
start.cmd           avvio con console visibile, per vedere i log
rendi-portabile.cmd copia node.exe nella cartella (opzionale)
server.js           server locale, solo moduli inclusi in Node
node.exe            presente solo se hai usato rendi-portabile.cmd
app\
  index.html        struttura della pagina
  styles.css        temi e componenti
  flow.ico          icona
  js\
    icons.js        icone SVG in linea
    util.js         date, DOM, markdown minimale
    store.js        stato, salvataggio, annulla/ripristina
    parse.js        interpretazione del linguaggio naturale
    views.js        rendering delle viste
    detail.js       pannello attività, menu, modali
    app.js          routing, eventi, trascinamento, scorciatoie
data\
  board.json        il tuo archivio
  backups\          copie automatiche
  server.log        log dell'ultimo avvio
```

Nessun `package.json`, nessun `node_modules`, niente da compilare.

---

## Copie di sicurezza

**La cartella non cresce all'infinito.** I backup ruotano: `data\backups\`
conserva al massimo **25** file `board-*.json` e cancella i più vecchi man mano.
Il tetto di spazio è quindi circa *25 × la dimensione di* `board.json` — con
qualche centinaio di attività si parla di pochi MB. Numero e peso complessivo
sono scritti in **Impostazioni**, sotto *Archivio dati*.

Tre regole tengono la cronologia utile invece che ingombrante:

- al massimo **una copia ogni 5 minuti**;
- la soglia dei 5 minuti è letta **dal disco**, non tenuta in memoria: il server
  si spegne ogni volta che chiudi la finestra, e una soglia in memoria
  ripartirebbe da zero facendo un backup a ogni avvio;
- se dall'ultima copia **non è cambiato nulla**, non ne viene creata un'altra
  identica.

I file di emergenza `illeggibile-*.json` (creati solo se `board.json` risulta
illeggibile) hanno una rotazione a parte: se ne tengono 5.

**Copie manuali**: Impostazioni → Esporta, oppure `Ctrl+E`. Ottieni un `.json`
con tutto dentro, ripristinabile da Impostazioni → Importa. Queste non vengono
mai cancellate: finiscono dove le salvi tu.

Se `board.json` dovesse risultare illeggibile, il server non lo sovrascrive: ne
mette una copia in `data\backups\illeggibile-<data>.json` e riparte da un archivio
nuovo, così hai sempre modo di recuperare a mano.
